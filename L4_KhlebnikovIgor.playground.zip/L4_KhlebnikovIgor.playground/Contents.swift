import UIKit

enum StateACar{
    enum EngineState:String{
        case on = "Включен"
        case off = "Выключен"
    }
    enum Windows:String{
        case open="Открыты"
        case close="Закрыты"
    }
    //        case stateEngine(engine: EngineState)
    //        case stateWindows(windows: Windows)
    case truncFilled(volume: Int)
}

enum Color{
    case red
    case black
    case silver
    case gray
    case white
}

class Car{
    var model: String//Наименование модели
    var yearOfIssue: String//год выпуска
    var length:Int?//длина
    var width:Int?//ширина
    var height:Int?//высота
    var enginePower:Int?//мощность двигателя
    var engineCapacity:Double?//объем двигателя
    
    var engineState : StateACar.EngineState?//двигатель включен/выключен
    var windowsState : StateACar.Windows?//окна открыты/закрыты
    var trunkFilled = StateACar.truncFilled(volume: 0)
    init(model:String,yearOfIssue: String) {
        self.model = model
        self.yearOfIssue = yearOfIssue
    }
    var strDef="параметр не задан"
    func printDescription()  {
        print("Автомобиль модель \(model), год выпуска \(yearOfIssue), мощность двигателя \(enginePower!), объем двигателя \(engineCapacity!)")
    }
    func openWindows(){
    }
    func closeWindows(){
    }
    func startEngine(){
    }
    func stopEngine(){
    }
    }

class SportCar: Car{
    enum BodyType{
    case sedan
    case hatchback
    case liftback
    case coupe
    case roadster
    }
    enum Transmission{
        case AKPP//автоматическая коробка передач
        case MKPP//механическая коробка передач
    }

    var bodyType:BodyType?//тип кузова
    var color:Color?//цвет кузова
    var typeTransmission:Transmission?//тип трансмиссии
    var maxSpeed:Int?//максимальная скорость км/ч
    override func openWindows() {
        windowsState = .open
    }
    override func closeWindows() {
        windowsState = .close
    }
    override func printDescription() {
        print("Автомобиль модель \(model), год выпуска \(yearOfIssue)г., мощность двигателя \(enginePower!) л.с., объем двигателя \(engineCapacity!) литра, максимальная скорость \(maxSpeed!) км/ч")
    }
    
    
}

class TruckCar: Car{
    var volume:Int?//объем кузова
    var loadingCapacity:Int?//грузоподъемность в тоннах
    
    override func printDescription() {
       print ("Автомобиль модель \(model), год выпуска \(yearOfIssue)г., мощность двигателя \(enginePower!) л.с., объем двигателя \(engineCapacity!) литра, грузоподъемность \(loadingCapacity!) тонн")    }
    
}

var toyotaSupra = SportCar(model: "TOYOTA Supra", yearOfIssue: "2002")
toyotaSupra.maxSpeed = 250
toyotaSupra.bodyType = .coupe
toyotaSupra.color = .red
toyotaSupra.enginePower = 197
toyotaSupra.engineCapacity = 3.5
toyotaSupra.printDescription()

var truckMan = TruckCar(model: "MAN TGX", yearOfIssue: "2008")
truckMan.engineCapacity = 4.5
truckMan.enginePower = 480
truckMan.loadingCapacity = 80
truckMan.printDescription()
